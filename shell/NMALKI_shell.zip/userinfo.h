#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <string.h>

static void info_user(char * username);
static void info_all_users(void);
